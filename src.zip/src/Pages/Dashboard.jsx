import React, { useEffect, useState } from "react";
import DashNavbar from "../Components/DashNavbar";
import StatsOverview from "../Components/StatsOverview";
import { getToken, fetchMe } from "../auth.jsx"; // ✅ updated import path

export default function Dashboard() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const token = getToken();
    if (!token) return;
    fetchMe().then((data) => {
      setUser(data?.user || null);
    });
  }, []);

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <DashNavbar />

      <main className="flex-1 p-4">
        <StatsOverview />
        {user && (
          <p className="mt-6 text-sm text-zinc-400">
            Logged in as <strong>{user.username || user.email}</strong>
          </p>
        )}
      </main>
    </div>
  );
}
