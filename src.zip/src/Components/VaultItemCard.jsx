import React from "react";
import { FileText, Folder, Clock, Download } from "lucide-react";

/**
 * VaultItemCard Component
 * Renders a File or Folder card based on backend response
 *
 * @param {Object} item - The file or folder data (from backend)
 * @param {Function} onFileClick - Called when user clicks a file
 * @param {Function} onFolderClick - Called when user clicks a folder
 */
export default function VaultItemCard({ item, onFileClick, onFolderClick }) {
  if (!item) return null;

  const isFolder = item.type?.toLowerCase() === "folder";
  const displayName = item.name || "Untitled";

  // Format timestamp safely
  const formattedDate = item.creationAT
    ? new Date(item.creationAT).toLocaleString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      })
    : "Unknown Date";

  // Handle clicks
  const handleClick = () => {
    if (isFolder) onFolderClick?.(item);
    else onFileClick?.(item);
  };

  return (
    <div
      onClick={handleClick}
      className="group bg-[#121212] border border-zinc-800 rounded-2xl p-4 shadow-sm hover:shadow-lg hover:border-blue-500/50 transition-all cursor-pointer flex flex-col gap-3"
    >
      {/* === Icon + Title === */}
      <div className="flex items-center gap-3">
        {isFolder ? (
          <Folder size={28} className="text-yellow-400 group-hover:text-yellow-300" />
        ) : (
          <FileText size={28} className="text-blue-400 group-hover:text-blue-300" />
        )}
        <div className="flex flex-col">
          <p className="font-medium text-zinc-200 truncate max-w-[200px]">
            {displayName}
          </p>
          <p className="text-xs text-zinc-500">
            {isFolder ? "Folder" : "File"}
          </p>
        </div>
      </div>

      {/* === Creation Date === */}
      <div className="flex items-center gap-2 text-xs text-zinc-500 mt-1">
        <Clock size={14} />
        <span>{formattedDate}</span>
      </div>

      {/* === Download Button for Files === */}
      {!isFolder && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onFileClick?.(item);
          }}
          className="mt-auto self-end flex items-center gap-1 text-xs text-blue-400 hover:text-blue-300"
        >
          <Download size={14} />
          <span>Download</span>
        </button>
      )}
    </div>
  );
}
