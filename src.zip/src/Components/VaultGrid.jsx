import React from "react";
import FileCard from "../Components/FileCard.jsx";

export default function VaultGrid({
  listView = false,
  folders = [],
  files = [],
  onOpenFolder,
  onDelete,
  onDownload,
  loading = false,
}) {
  // 🔹 Normalize item to ensure consistent structure
  const normalizeItem = (type, data) => ({
    id: data.id || data._id || data.uuid || Math.random().toString(36).slice(2),
    name: data.name || data.filename || "Untitled",
    type,
    ...data,
  });

  // ✅ Handle empty state
  if (!loading && folders.length === 0 && files.length === 0) {
    return (
      <div className="text-center text-sm text-zinc-500 mt-10">
        No files or folders yet.
        <br />
        <span className="text-zinc-400">
          Upload or create a new folder to get started.
        </span>
      </div>
    );
  }

  return (
    <div
      className={
        listView
          ? "flex flex-col gap-3 mt-6"
          : "grid gap-4 mt-6 [grid-template-columns:repeat(auto-fill,minmax(160px,1fr))]"
      }
    >
      {/* === Folders === */}
      {folders.map((folder) => {
        const item = normalizeItem("folder", folder);
        return (
          <FileCard
            key={item.id}
            item={item}
            listView={listView}
            onOpen={onOpenFolder ? () => onOpenFolder(item) : undefined}
            onDelete={onDelete ? () => onDelete(item.id) : undefined}
            onDownload={onDownload ? () => onDownload(item.id, item.name) : undefined}
          />
        );
      })}

      {/* === Files === */}
      {files.map((file) => {
        const item = normalizeItem("file", file);
        return (
          <FileCard
            key={item.id}
            item={item}
            listView={listView}
            onDelete={onDelete ? () => onDelete(item.id) : undefined}
            onDownload={onDownload ? () => onDownload(item.id, item.name) : undefined}
          />
        );
      })}
    </div>
  );
}
