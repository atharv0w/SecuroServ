import React from "react";
import { Trash2, Download } from "lucide-react";

export default function FileCard({ item, listView, onOpen, onDelete, onDownload }) {
  const isFolder = item.type === "folder";

  // Handle keyboard accessibility (Enter to open folder)
  const handleKeyDown = (e) => {
    if (isFolder && (e.key === "Enter" || e.key === " ")) {
      onOpen?.(item);
    }
  };

  return (
    <div
      onClick={() => (isFolder ? onOpen?.(item) : undefined)}
      onKeyDown={handleKeyDown}
      className={
        "group relative rounded-xl border border-zinc-800 bg-[#121212] text-zinc-200 transition-colors hover:bg-zinc-900 " +
        (listView
          ? "w-full p-3 flex items-center gap-3"
          : "w-[160px] h-[140px] p-4 flex flex-col justify-center items-center text-center")
      }
      role="button"
      tabIndex={0}
    >
      {/* === Icon === */}
      <div className={listView ? "text-2xl" : "text-3xl mb-2"}>
        {isFolder ? "📁" : "📄"}
      </div>

      {/* === File/Folder Name === */}
      <div className="text-sm text-zinc-300 break-all line-clamp-2">{item.name}</div>

      {/* === Hover Action Buttons === */}
      <div className="absolute right-2 top-2 flex gap-2 opacity-0 group-hover:opacity-100 focus-within:opacity-100">
        {/* Download Button */}
        <button
          type="button"
          className="inline-flex items-center gap-1 rounded-md border border-zinc-800 bg-zinc-950 px-2 py-1 text-[11px] text-zinc-300"
          onClick={(e) => {
            e.stopPropagation();
            onDownload?.(item);
          }}
          title="Download"
        >
          <Download size={12} /> Download
        </button>

        {/* Delete Button */}
        <button
          type="button"
          className="inline-flex items-center gap-1 rounded-md border border-zinc-800 bg-zinc-950 px-2 py-1 text-[11px] text-zinc-300"
          onClick={(e) => {
            e.stopPropagation();
            onDelete?.(item);
          }}
          title="Delete"
        >
          <Trash2 size={12} /> Remove
        </button>
      </div>
    </div>
  );
}
