import { useEffect } from "react";

const Features = () => {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("opacity-100", "translate-y-0", "translate-x-0");
            observer.unobserve(e.target);
          }
        });
      },
      { threshold: 0.15 }
    );

    document.querySelectorAll(".fade-in").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#070707] to-[#0f0f10] text-[#e6e7e8] font-[Poppins] pb-16">
      {/* Navbar */}
      <header className="sticky top-0 z-40 backdrop-blur-md bg-black/40 border-b border-white/5 px-7 py-3 flex items-center">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-cyan-400 to-cyan-200 grid place-items-center text-black font-bold">
            SS
          </div>
          <div>
            <h1 className="font-bold text-lg">SecuroServ</h1>
            <p className="text-xs text-gray-400">Secure Vault • Local-first Storage</p>
          </div>
        </div>
        <nav className="ml-auto flex items-center gap-3">
          <a href="/" className="text-sm font-medium text-gray-400 hover:text-white">
            Home
          </a>
          <a
            href="#cta"
            className="bg-cyan-500/10 border border-cyan-400/10 text-white px-3 py-2 rounded-lg text-sm font-semibold hover:bg-cyan-500/20 transition"
          >
            Get Started
          </a>
        </nav>
      </header>

      {/* Hero */}
      <section className="max-w-6xl mx-auto px-6 py-16">
        <div className="flex flex-col md:flex-row items-center gap-10">
          <div className="flex-1 space-y-4">
            <div className="inline-flex items-center px-3 py-1 border border-white/10 rounded-full text-sm text-gray-400 fade-in opacity-0 translate-y-6 transition duration-700">
              Features
            </div>
            <h1 className="text-4xl font-bold fade-in opacity-0 translate-y-6 transition duration-700">
              Why choose SecuroServ?
            </h1>
            <p className="text-gray-400 fade-in opacity-0 translate-y-6 transition duration-700">
              Powerful hierarchical encryption, local-first storage on your own desktop/server, and a
              privacy-focused pipeline where encryption happens centrally on your server while uploads
              are compressed on the client.
            </p>
            <div className="flex flex-wrap gap-4 text-xs uppercase tracking-widest text-gray-500 fade-in opacity-0 translate-y-6 transition duration-700">
              <span>Local-first</span>
              <span>•</span>
              <span>Hierarchical Encryption</span>
              <span>•</span>
              <span>No Sharing</span>
            </div>
          </div>

          <div className="w-20 h-20 rounded-2xl bg-white/[0.03] grid place-items-center border border-white/[0.05] shadow-lg fade-in opacity-0 translate-y-6 transition duration-700">
            <svg
              width="56"
              height="56"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M12 2L4 5v5c0 5.25 3.6 10 8 11 4.4-1 8-5.75 8-11V5l-8-3z"
                fill="white"
                opacity="0.95"
              />
              <path d="M12 8a4 4 0 100 8 4 4 0 000-8z" fill="#071216" opacity="0.95" />
            </svg>
          </div>
        </div>
      </section>

      {/* ===== FEATURE SECTIONS ===== */}
      <div className="max-w-6xl mx-auto px-6 space-y-20">
        {/* 1. Local Storage */}
        <FeatureRow
          title="Local / Home Server Storage"
          desc="Store files directly on your own desktop or home server. SecuroServ connects to your PC as the primary storage node — no third-party cloud is involved."
          detail="This local-first model gives you physical control: files live on your hardware, accessible via authenticated connections to your server."
          direction="normal"
          svg={
            <svg viewBox="0 0 120 80" xmlns="http://www.w3.org/2000/svg">
              <rect x="8" y="18" width="104" height="52" rx="8" fill="#0b0b0c" stroke="#1a1a1a" />
              <rect x="18" y="26" width="36" height="10" rx="2" fill="#101214" />
              <rect x="18" y="40" width="84" height="6" rx="2" fill="#121316" />
            </svg>
          }
        />

        {/* 2. Hierarchical Encryption */}
        <FeatureRow
          title="Hierarchical Encryption — Multiple Levels"
          desc="Files and folders are protected by layered keys: root → folder → file. Each level's key can be rotated or revoked independently."
          detail="This structure ensures granular control and efficiency, ideal for complex folder hierarchies and large datasets."
          direction="reverse"
          svg={
            <svg viewBox="0 0 120 80" xmlns="http://www.w3.org/2000/svg">
              <g transform="translate(10,8)" fill="none" stroke="#8adfe3" strokeWidth="2">
                <rect x="0" y="0" width="100" height="60" rx="8" opacity="0.12" />
                <rect x="6" y="8" width="88" height="44" rx="6" opacity="0.08" />
                <rect x="12" y="16" width="76" height="28" rx="5" opacity="0.06" />
              </g>
            </svg>
          }
        />

        {/* 3. Backend Encryption */}
        <FeatureRow
          title="Backend Encryption Pipeline"
          desc="Encryption is performed on your server. Files are compressed on the client, transferred, then encrypted and stored on your local server."
          detail="This means SecuroServ does not use zero-knowledge encryption — all cryptographic operations occur under your direct server control."
          direction="normal"
        />

        {/* 4. Frontend Compression */}
        <FeatureRow
          title="Frontend: Compression Only"
          desc="The client compresses files before upload to optimize bandwidth and performance."
          detail="Sensitive operations — encryption and key management — stay server-side under your administration."
          direction="reverse"
        />

        {/* 5. No Sharing */}
        <FeatureRow
          title="No Sharing — Single Owner Model"
          desc="SecuroServ is designed for private, single-owner storage. There is no built-in file sharing mechanism."
          detail="Removing sharing minimizes attack surface and keeps security boundaries simple — files remain private and accessible only through your authenticated vault."
          direction="normal"
        />

        {/* 6. Activity Tracking */}
        <FeatureRow
          title="Activity & Audit Tracking"
          desc="Detailed logs capture uploads, downloads, key rotations, and events."
          detail="All logs are stored locally on your server for full control, visibility, and compliance auditing."
          direction="reverse"
        />
      </div>

      {/* CTA */}
      <section
        id="cta"
        className="text-center max-w-3xl mx-auto px-6 py-20 fade-in opacity-0 translate-y-8 transition duration-700"
      >
        <h3 className="text-2xl font-semibold mb-3">Your security starts on your machine.</h3>
        <p className="text-gray-400 mb-6">
          Use SecuroServ to keep files encrypted and local, with full auditability and hierarchical key
          management.
        </p>
        <div className="flex justify-center gap-3 flex-wrap">
          <button
            onClick={() => (window.location.href = "/dashboard")}
            className="px-5 py-3 bg-cyan-400 text-black font-semibold rounded-lg hover:bg-cyan-300 transition"
          >
            Go to Dashboard
          </button>
          <a
            href="/docs/setup"
            className="border border-white/10 text-gray-300 px-5 py-3 rounded-lg text-sm hover:bg-white/5"
          >
            Setup Guide
          </a>
        </div>
      </section>


     
    </div>
  );
};

// ✅ Reusable Feature Row component
const FeatureRow = ({ title, desc, detail, direction = "normal", svg }) => {
  const isReverse = direction === "reverse";
  return (
    <section
      className={`flex flex-col ${
        isReverse ? "md:flex-row-reverse" : "md:flex-row"
      } items-center gap-10 border-b border-white/5 pb-12`}
    >
      <div className="flex-1 space-y-3 fade-in opacity-0 translate-x-8 transition duration-700">
        <h2 className="text-xl font-semibold flex items-center gap-2">{title}</h2>
        <p className="text-gray-400">{desc}</p>
        <p className="text-sm text-gray-500">{detail}</p>
      </div>
      <div className="flex-1 fade-in opacity-0 -translate-x-8 transition duration-700">
        <div className="rounded-xl bg-white/[0.02] border border-white/[0.05] p-6 grid place-items-center shadow-lg min-h-[160px]">
          {svg || (
            <div className="text-gray-500 italic text-sm">[Illustration Placeholder]</div>
          )}
        </div>
      </div>
    </section>
  );
};

export default Features;
