// src/api/VaultApi.js

const API = {
  baseURL: import.meta.env.VITE_API_BASE || "https://lucille-unbatted-monica.ngrok-free.dev/",
  endpoints: {
    // 🔹 GET: Total user storage used
    usage: "/vault/usage",

    // 🔹 GET: List folders & files separately
    folders: "/vault/folders", // GET ?parentId=<id>
    files: "/vault/files",     // GET ?parentId=<id>

    // 🔹 POST: Create new folder or upload folder
    uploadFolder: "/encryption/upload-folder",

    // 🔹 POST: Upload files (encrypted)
    uploadFile: "/encryption/upload",

    // 🔹 DELETE & DOWNLOAD
    deleteItem: "/vault/item/",
    downloadBase: "/vault/item/",
  },
};

// --- Auth Helpers ---
const getToken = () =>
  localStorage.getItem("sv_token") || localStorage.getItem("authToken") || "";

const authHeaders = () => ({
  Authorization: `Bearer ${getToken()}`,
});

// --- Generic Fetch Helper ---
export async function apiRequest(method, path, { body, isForm = false, expect = "json" } = {}) {
  const url = API.baseURL.replace(/\/$/, "") + path;
  const headers = isForm ? { ...authHeaders() } : { "Content-Type": "application/json", ...authHeaders() };

  const res = await fetch(url, {
    method,
    headers,
    body: body
      ? isForm
        ? body
        : typeof body === "string"
        ? body
        : JSON.stringify(body)
      : undefined,
  });

  if (!res.ok) {
    const msg = await res.text().catch(() => "");
    throw new Error(msg || `Request failed (${res.status})`);
  }

  if (expect === "blob") return { blob: await res.blob(), headers: res.headers };
  if (res.status === 204) return {};
  return res.json().catch(() => ({}));
}

// --- Main Vault API Object ---
export const vaultApi = {
  /* 1️⃣ Get total user storage usage */
  getUsage() {
    return apiRequest("GET", API.endpoints.usage);
  },

  /* 2️⃣ Upload a folder (folder metadata or zipped upload) */
  uploadFolder(files, parentId) {
  const token = getToken();

  // Backend expects: one file per request with `file` + `relativePath`
  const uploadPromises = files.map(async (file) => {
    const form = new FormData();
    form.append("file", file); // must be "file" to match backend @RequestParam
    form.append("relativePath", file.webkitRelativePath || file.name);
    if (parentId) form.append("parentId", parentId);

    const res = await fetch(
      API.baseURL.replace(/\/$/, "") + API.endpoints.uploadFolder,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: form,
      }
    );

    if (!res.ok) {
      const msg = await res.text().catch(() => "");
      throw new Error(msg || `Failed to upload ${file.name}`);
    }

    return res.json().catch(() => ({}));
  });

  return Promise.all(uploadPromises);
},
  /* 3️⃣ Upload one or more files */
  uploadFiles(files, parentId) {
    const form = new FormData();
    for (const f of files) form.append("files", f);
    if (parentId) form.append("parentId", parentId);

    return apiRequest("POST", API.endpoints.uploadFile, { body: form, isForm: true });
  },

  /* 4️⃣ Get files in a folder */
  getFiles(parentId) {
    const qs = parentId ? `?parentId=${encodeURIComponent(parentId)}` : "";
    return apiRequest("GET", `${API.endpoints.files}${qs}`);
  },

  /* 5️⃣ Get folders in a folder */
  getFolders(parentId) {
    const qs = parentId ? `?parentId=${encodeURIComponent(parentId)}` : "";
    return apiRequest("GET", `${API.endpoints.folders}${qs}`);
  },

  /* 🗑️ Delete item (file/folder) */
  deleteItem(id) {
    return apiRequest("DELETE", API.endpoints.deleteItem + encodeURIComponent(id));
  },

  /* ⬇️ Download item by ID */
  downloadById(id) {
    return apiRequest(
      "GET",
      API.endpoints.downloadBase + encodeURIComponent(id) + "/download",
      { expect: "blob" }
    );
  },
};

/* ---------- Utility Helpers ---------- */
export function getFilenameFromDisposition(hdr, fallback) {
  if (!hdr) return fallback;
  // Handles: filename="x", filename*=UTF-8''x
  const m = /filename\*?=(?:UTF-8''|")?([^\";]+)/i.exec(hdr);
  const raw = (m?.[1] || fallback).replace(/"/g, "");
  try {
    return decodeURIComponent(raw);
  } catch {
    return raw || fallback;
  }
}

export async function triggerDownload({ blob, filename }) {
  const a = document.createElement("a");
  const url = URL.createObjectURL(blob);
  a.href = url;
  a.download = filename || "download.bin";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

// Demo fallback to simulate file download
export async function demoDownload(name = "demo.txt") {
  const blob = new Blob([`Demo content for ${name}\n`], { type: "text/plain" });
  await triggerDownload({ blob, filename: name });
}
