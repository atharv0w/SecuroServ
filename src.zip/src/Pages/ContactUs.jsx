import React from "react";
import { Mail, Clock, Shield } from "lucide-react";
import { motion } from "framer-motion";

export default function ContactUs() {
  const handleSupportClick = () => {
    window.open("mailto:support@securoserv.com", "_blank");
  };

  return (
    <div className="min-h-[90vh] flex items-center justify-center bg-neutral-950 text-white py-20 px-8 relative overflow-hidden">
      <motion.div
  initial={{ opacity: 0, y: 30 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ duration: 0.8, ease: "easeOut" }}
  className="max-w-6xl w-full bg-neutral-900 p-14 rounded-3xl shadow-2xl border border-neutral-800 grid md:grid-cols-2 gap-16 min-h-[520px]"
>

        {/* Left Section */}
<div className="flex flex-col justify-center">
  <div className="mb-10">
    <h1 className="text-4xl font-extrabold mb-6">Contact SecuroServ</h1>
    <p className="text-neutral-400 leading-relaxed text-[1.05rem]">
      Encountered a problem, need assistance, or have a suggestion? We’re here to help —
      reach out to us directly via email.
    </p>
  </div>

  <div className="space-y-6">
    <motion.div
      whileHover={{ scale: 1.03 }}
      transition={{ type: "spring", stiffness: 250 }}
      className="flex items-center gap-3 bg-neutral-800 p-5 rounded-xl cursor-pointer hover:bg-neutral-700 transition duration-300 shadow-lg"
      onClick={handleSupportClick}
    >
      <Mail className="w-6 h-6 text-purple-400" />
      <span className="text-neutral-200 text-[1.05rem]">support@securoserv.com</span>
    </motion.div>

    <div className="flex items-center gap-3 bg-neutral-800 p-5 rounded-xl shadow-lg">
      <Clock className="w-6 h-6 text-pink-400" />
      <span className="text-neutral-200 text-[1.05rem]">
        Available: Mon–Sat | 10:00 AM – 7:00 PM
      </span>
    </div>
  </div>
</div>

        {/* Right Section - Support Desk */}
        <motion.div
          whileHover={{ scale: 1.05 }}
          transition={{ type: "spring", stiffness: 200 }}
          onClick={handleSupportClick}
          className="relative bg-neutral-800 rounded-2xl p-10 text-center cursor-pointer border border-neutral-700 overflow-hidden group flex flex-col justify-center shadow-xl"
        >
          {/* Shiny hover animation */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-200%] group-hover:translate-x-[200%] transition-transform duration-1000 ease-in-out" />

          <div className="flex justify-center mb-6 relative z-10">
            <Shield className="w-16 h-16 text-purple-400 group-hover:text-purple-300 transition duration-300" />
          </div>

          <h2 className="text-2xl font-semibold mb-3 relative z-10">SecuroServ Support Desk</h2>
          <p className="text-neutral-400 text-base leading-relaxed relative z-10 max-w-xs mx-auto">
            Our specialists ensure secure handling of every query — keeping your data safe and confidential.
          </p>
        </motion.div>
      </motion.div>

      <footer className="absolute bottom-8 text-neutral-600 text-sm text-center w-full">
        © 2025 SecuroServ — All Rights Reserved
      </footer>
    </div>
  );
}
