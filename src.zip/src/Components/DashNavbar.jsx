import React from "react";
import { useNavigate } from "react-router-dom";

export default function DashNavbar() {
  const navigate = useNavigate();

  const handleLogout = () => {
    // ✅ Clear auth token (or any user data)
    localStorage.removeItem("authToken");
    localStorage.removeItem("username"); // if you store username etc.

    // ✅ Redirect to login page
    navigate("/login");
  };

  return (
    <header className="w-full bg-neutral-950 border-b border-neutral-800 px-6 py-4 flex justify-between items-center">
      <h1 className="text-xl font-bold">Secure Vault Dashboard</h1>
      <div className="flex space-x-6 text-gray-400">
        <button className="hover:text-white transition">Profile</button>
        <button
          onClick={handleLogout}
          className="hover:text-white transition"
        >
          Logout
        </button>
      </div>
    </header>
  );
}
