import React from "react";
import LandingPageComponent from "../Components/LandingPageComponent";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-black text-white">
      <LandingPageComponent />
    </div>
  );
}
