import React from "react";
import { FileText, Upload, Shield } from "lucide-react";

export default function Sidebar() {
  return (
    <aside className="w-64 bg-neutral-950 border-r border-neutral-800 p-6 hidden md:flex flex-col">
      <nav className="space-y-6">
        <a href="#files" className="flex items-center space-x-3 text-gray-400 hover:text-white transition">
          <FileText className="w-5 h-5 text-yellow-400" />
          <span>My Files</span>
        </a>
        <a href="#upload" className="flex items-center space-x-3 text-gray-400 hover:text-white transition">
          <Upload className="w-5 h-5 text-blue-400" />
          <span>Upload</span>
        </a>
        <a href="#security" className="flex items-center space-x-3 text-gray-400 hover:text-white transition">
          <Shield className="w-5 h-5 text-pink-400" />
          <span>Security</span>
        </a>
      </nav>
    </aside>
  );
}
