// src/components/Sidebar.jsx
import React from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { FolderKanban, Menu, ChevronLeft, LogOut, Lock } from "lucide-react"; // ✅ Changed Shield → Lock

export default function Sidebar({
  collapsed = false,
  onToggle,
  onLogout,
}) {
  const navigate = useNavigate();
  const widthClass = collapsed ? "w-[74px]" : "w-[240px]";

  const handleLogout = () => {
    try {
      localStorage.removeItem("authToken");
      localStorage.removeItem("username");

      if (onLogout) onLogout();
      else navigate("/login", { replace: true });
    } catch (err) {
      console.error("Logout error:", err);
      navigate("/login", { replace: true });
    }
  };

  return (
    <aside
      className={`${widthClass} shrink-0 flex flex-col overflow-hidden
                  transition-[width] duration-200
                  bg-[#0E0E0F] text-zinc-200 border-r border-zinc-800`}
    >
      {/* === Brand === */}
      <div className="h-14 flex items-center gap-2 px-5">
        <Lock
          size={collapsed ? 18 : 22}
          strokeWidth={2.2}
          className="text-zinc-100 transition-all duration-300"
        />
        {!collapsed && (
          <span className="font-bold tracking-wide select-none text-[1.15rem] text-zinc-100">
            SecuroServ
          </span>
        )}
      </div>

      {/* === Collapse Button === */}
      <div className="px-3 py-2">
        <div className="flex items-center gap-2">
          <button
            onClick={() => onToggle?.()}
            className="inline-flex items-center justify-center rounded-lg border border-zinc-800 bg-zinc-900/70 p-2
                       hover:bg-zinc-900 transition-colors
                       focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/40"
            title={collapsed ? "Expand" : "Collapse"}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            type="button"
          >
            {collapsed ? <Menu size={16} /> : <ChevronLeft size={16} />}
          </button>
          {!collapsed && (
            <span className="text-sm font-semibold tracking-wide select-none text-zinc-300">
              Navigation
            </span>
          )}
        </div>
      </div>

      {/* === Navigation Links === */}
      <nav
        className="flex-1 px-3 pt-1 overflow-y-auto overscroll-contain
                   [scrollbar-width:none] [-ms-overflow-style:none]"
      >
        <ul className="space-y-2">
          <li>
            <NavLink
              to="/my-vault"
              end={false}
              className={({ isActive }) =>
                [
                  "group flex items-center rounded-xl px-3 py-2 text-sm transition-all",
                  "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/40",
                  isActive
                    ? "bg-white/7.5 text-white shadow-[inset_0_1px_0_0_rgba(255,255,255,.04)] ring-1 ring-white/10"
                    : "text-zinc-300 hover:text-white hover:bg-white/5 hover:shadow-[inset_0_1px_0_0_rgba(255,255,255,.03)]",
                ].join(" ")
              }
              title={collapsed ? "My Vault" : undefined}
            >
              <span
                className="mr-2 h-3 w-[3px] rounded-full opacity-0 group-hover:opacity-60
                           group-[.active]:opacity-100 transition-opacity"
                style={{
                  background: "linear-gradient(180deg,#60a5fa,#34d399)",
                }}
                aria-hidden="true"
              />
              <FolderKanban
                size={18}
                className="shrink-0 opacity-90 group-hover:opacity-100 transition-opacity"
              />
              {!collapsed && <span className="ml-2">My Vault</span>}
            </NavLink>
          </li>
        </ul>
      </nav>

      {/* === Footer / Logout === */}
      <div className="p-3 border-t border-zinc-800/80 bg-[#0E0E0F]">
        <button
          onClick={handleLogout}
          className={`w-full inline-flex items-center gap-2 rounded-lg
                      border border-zinc-800 bg-zinc-900/70 px-3 py-2 text-sm text-zinc-300
                      hover:bg-zinc-900 hover:text-white
                      focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/40
                      transition-colors ${collapsed ? "justify-center" : "justify-start"}`}
          title={collapsed ? "Logout" : undefined}
          type="button"
        >
          <LogOut size={18} />
          {!collapsed && <span>Logout</span>}
        </button>
      </div>
    </aside>
  );
}
