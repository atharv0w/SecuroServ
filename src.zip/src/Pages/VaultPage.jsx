import React, { useCallback, useEffect, useMemo, useState } from "react";
import { List, Grid2X2, FolderPlus, HardDrive } from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";
import VaultNavbar from "../Components/VaultNavbar.jsx";
import DualDragAndDrop from "../Components/DualDragAndDrop.jsx";
import Breadcrumb from "../Components/Breadcrumb.jsx";
import VaultGrid from "../Components/VaultGrid.jsx";
import CreateFolderModal from "../Components/CreateFolderModal.jsx"; // ✅ New Import
import VaultItemCard from "../Components/VaultItemCard.jsx";
const API_BASE = "https://lucille-unbatted-monica.ngrok-free.dev";

/* ========== Helper Functions ========== */
function getToken() {
  return localStorage.getItem("authToken") || "";
}

function apiPath(folderId) {
  return folderId ? `${API_BASE}/${encodeURIComponent(folderId)}` : API_BASE;
}

async function apiFetch(path, options = {}) {
  const token = getToken();
  const headers = new Headers(options.headers || {});
  if (!headers.has("Authorization")) headers.set("Authorization", `Bearer ${token}`);

  const res = await fetch(path, { ...options, headers });
  if (res.status === 401) throw Object.assign(new Error("Unauthorized"), { code: 401 });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(text || `Request failed (${res.status})`);
  }
  return res;
}

/* ========== Vault Page ========== */
export default function VaultPage() {
  const navigate = useNavigate();
  const { folderId } = useParams();

  const [listView, setListView] = useState(false);
  const [folders, setFolders] = useState([]);
  const [files, setFiles] = useState([]);
  const [crumbs, setCrumbs] = useState([]);
  const [usage, setUsage] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [showCreateModal, setShowCreateModal] = useState(false); // ✅ Modal State

  const listUrl = useMemo(() => apiPath(folderId), [folderId]);

  /* === Fetch Usage === */
  const fetchUsage = useCallback(async () => {
    try {
      const res = await apiFetch(`${API_BASE}/usage`, { method: "GET" });
      const data = await res.json();
      setUsage(data.totalUsed || 0);
    } catch (e) {
      console.error("Failed to fetch usage:", e);
    }
  }, []);

 /* === Fetch Folders & Files === */
const fetchList = useCallback(async () => {
  setLoading(true);
  setError("");
  try {
    const folderRes = await apiFetch(`${API_BASE}/vault/folders${folderId ? `?parentId=${folderId}` : ""}`, { method: "GET" });
    const fileRes = await apiFetch(`${API_BASE}/vault/files${folderId ? `?parentId=${folderId}` : ""}`, { method: "GET" });

    const folderData = await folderRes.json();
    const fileData = await fileRes.json();

    setFolders(folderData || []);
    setFiles(fileData || []);
    setCrumbs([]); // optional: if your backend supports breadcrumb info
  } catch (e) {
    if (e.code === 401) return navigate("/login");
    setError(e.message || "Failed to load data");
  } finally {
    setLoading(false);
    fetchUsage();
  }
}, [folderId, navigate, fetchUsage]);


  /* === Upload Folder === */
  const uploadFolder = useCallback(
    async (folders) => {
      try {
        const form = new FormData();
        folders.forEach((f) => form.append("folder", f));
        await apiFetch(`${API_BASE}/encryption/upload-folder`, {
          method: "POST",
          body: form,
        });
        fetchList();
      } catch (e) {
        setError(e.message || "Failed to upload folder");
      }
    },
    [fetchList]
  );

  /* === Upload Files === */
  const uploadFiles = useCallback(
    async (newFiles) => {
      try {
        const form = new FormData();
        newFiles.forEach((f) => form.append("files", f));
        await apiFetch(`${API_BASE}/encryption/upload`, {
          method: "POST",
          body: form,
        });
        fetchList();
      } catch (e) {
        setError(e.message || "File upload failed");
      }
    },
    [fetchList]
  );

  return (
    <div className="min-h-screen bg-[#0b0b0b] text-zinc-200">
      <div className="max-w-7xl mx-auto px-6 py-6">
        {/* === Top Controls === */}
        <div className="flex items-center justify-between mb-6">
          <Breadcrumb crumbs={crumbs} onNavigate={(id) => navigate(id ? `/vault/${id}` : "/vault")} />
          <div className="flex items-center gap-3">
            {usage !== null && (
              <div className="flex items-center gap-2 text-sm text-zinc-400">
                <HardDrive size={18} />
                <span>{(usage / 1024 / 1024).toFixed(2)} MB used</span>
              </div>
            )}
            <button
              onClick={() => setListView((v) => !v)}
              className="p-2 rounded-lg border border-zinc-700 hover:bg-zinc-800"
              title={listView ? "Grid view" : "List view"}
            >
              {listView ? <Grid2X2 size={20} /> : <List size={20} />}
            </button>
            <button
              onClick={() => setShowCreateModal(true)}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all shadow-md shadow-blue-500/20"
            >
            <FolderPlus size={20} className="text-white" />
                New Folder
            </button>

          </div>
        </div>

        {/* === Error Banner === */}
        {error && (
          <div className="mb-4 p-4 bg-red-900/30 border border-red-700 text-red-400 rounded">
            {error}
          </div>
        )}

        {/* === Dual Upload Boxes === */}
        <div className="flex flex-col md:flex-row gap-6 justify-between mt-8">
          <div className="flex-1">
            <DualDragAndDrop onUploadFolder={uploadFolder} onUploadFiles={uploadFiles} />
          </div>
        </div>
{/* === Uploaded Items Section === */}
<div className="mt-8 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
  {folders.map((folder) => (
    <VaultItemCard key={folder.folderId || folder.name} item={folder} />
  ))}
  {files.map((file) => (
    <VaultItemCard key={file.fileId || file.name} item={file} />
  ))}
</div>
        {/* === Vault Grid === */}
        <VaultGrid
          folders={folders}
          files={files}
          loading={loading}
          listView={listView}
          onFolderClick={(folder) => navigate(`/vault/${folder.id}`)}
          onFileClick={(file) =>
            apiFetch(`${API_BASE}/files/${encodeURIComponent(file.id)}/download`).then(async (res) => {
              const blob = await res.blob();
              const url = URL.createObjectURL(blob);
              const a = document.createElement("a");
              a.href = url;
              a.download = file.name;
              a.click();
              URL.revokeObjectURL(url);
            })
          }
        />
      </div>

      {/* === Create Folder Modal === */}
      <CreateFolderModal
        open={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onCreate={(name) => uploadFolder([{ name }])}
      />
    </div>
  );
}
