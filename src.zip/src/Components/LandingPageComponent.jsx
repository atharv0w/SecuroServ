import React from "react";
import { Lock, Cloud, Rocket } from "lucide-react";

export default function LandingPageComponent() {
  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center px-6">
      {/* Header Section */}
      <div className="text-center max-w-2xl mt-40">
        <h1 className="text-5xl md:text-6xl font-extrabold mb-6 leading-tight">
          Secure File Storage
        </h1>
        <p className="text-gray-400 mb-8 text-lg md:text-xl leading-relaxed">
          Upload, encrypt, and store your files with enterprise-grade security.
          Your data stays private, always.
        </p>
        <a
          href="/signup"
          className="px-8 py-3 bg-white text-black rounded-md font-semibold hover:bg-gray-200 transition text-lg"
        >
          Get Started
        </a>
      </div>

      {/* Features Section */}
      <div
        id="features"
        className="mt-40 md:mt-48 grid grid-cols-1 md:grid-cols-3 gap-12 max-w-6xl w-full mb-32"
      >
        <div className="bg-neutral-900 p-10 min-h-[280px] rounded-xl text-center shadow-lg transform transition duration-500 hover:-translate-y-3 hover:scale-105 hover:shadow-2xl hover:shadow-yellow-500/30">
          <Lock className="mx-auto w-14 h-14 text-yellow-400 mb-6" />
          <h3 className="text-2xl font-semibold mb-4">Client-Side Encryption</h3>
          <p className="text-gray-400 text-base leading-relaxed">
            Files are encrypted on your device before upload.
            We never see your unencrypted data.
          </p>
        </div>

        <div className="bg-neutral-900 p-10 min-h-[280px] rounded-xl text-center shadow-lg transform transition duration-500 hover:-translate-y-3 hover:scale-105 hover:shadow-2xl hover:shadow-blue-500/30">
          <Cloud className="mx-auto w-14 h-14 text-blue-400 mb-6" />
          <h3 className="text-2xl font-semibold mb-4">Secure Storage</h3>
          <p className="text-gray-400 text-base leading-relaxed">
            Your encrypted files are stored securely in our cloud infrastructure.
          </p>
        </div>

        <div className="bg-neutral-900 p-10 min-h-[280px] rounded-xl text-center shadow-lg transform transition duration-500 hover:-translate-y-3 hover:scale-105 hover:shadow-2xl hover:shadow-pink-500/30">
          <Rocket className="mx-auto w-14 h-14 text-pink-400 mb-6" />
          <h3 className="text-2xl font-semibold mb-4">Fast Access</h3>
          <p className="text-gray-400 text-base leading-relaxed">
            Quick uploads and downloads with reliable performance.
          </p>
        </div>
      </div>
    </div>
  );
}
