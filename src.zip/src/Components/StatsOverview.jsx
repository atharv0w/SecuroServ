import React, { useState, useEffect } from "react";
import {
  Shield,
  FolderLock,
  Clock,
  HardDrive,
  ChevronRight,
  Lock,
} from "lucide-react";

const useAuth = () => {
  const [user, setUser] = useState(null);
  useEffect(() => {
    const token = localStorage.getItem("authToken");
    const username = localStorage.getItem("username") || "User";
    if (token) setUser({ username });
  }, []);
  return user;
};

const Card = ({ children, className = "" }) => (
  <div
    className={
      "rounded-2xl border border-zinc-800/70 bg-zinc-950/70 backdrop-blur " +
      className
    }
  >
    {children}
  </div>
);

const StatCard = ({ icon: Icon, label, value, ringClass }) => (
  <Card className="p-5 md:p-6 hover:-translate-y-0.5 hover:border-zinc-700 transition-all duration-200">
    <div className="flex items-start justify-between gap-4">
      <div>
        <p className="text-xs uppercase tracking-wide text-zinc-500">{label}</p>
        <p className="mt-1 text-2xl font-semibold text-white">{value}</p>
      </div>
      <div
        className={`grid size-11 place-items-center rounded-xl ${ringClass}`}
      >
        <Icon className="h-[20px] w-[20px] text-white" />
      </div>
    </div>
  </Card>
);

export default function Dashboard() {
  const user = useAuth();
  const [greeting, setGreeting] = useState("Welcome");

  useEffect(() => {
    const hour = new Date().getHours();
    if (hour < 12) setGreeting("Good morning");
    else if (hour < 18) setGreeting("Good afternoon");
    else setGreeting("Good evening");
  }, []);

  const navigateToVault = () => {
    window.location.href = "/my-vault";
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Main content (no header strip now) */}
      <main className="mx-auto max-w-7xl px-6 py-8">
        {/* Greeting */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">{greeting} 👋</h1>
            <p className="mt-1 text-zinc-500">
              Manage your secure files in the vault
            </p>
          </div>

          {user && (
            <div className="flex items-center gap-3">
              <div className="grid size-10 place-items-center rounded-full border border-zinc-800 bg-zinc-900">
                <span className="text-sm font-medium">
                  {user.username.charAt(0).toUpperCase()}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
          
          <StatCard
            icon={HardDrive}
            label="Storage Used"
            value="2.4 GB"
            ringClass="bg-purple-600/20"
          />
       
        </div>

        {/* Vault Action */}
        <Card className="p-8 text-center">
          <div className="mx-auto max-w-xl">
            <div className="mx-auto mb-6 grid size-16 place-items-center rounded-full border border-zinc-800 bg-zinc-900">
              <FolderLock className="h-8 w-8" />
            </div>
            <h2 className="text-xl font-bold mb-2">Your Secure Vault</h2>
            <p className="text-zinc-400 mb-6">
              All your files are encrypted and stored safely. Open your vault to manage them.
            </p>
            <button
              onClick={navigateToVault}
              className="inline-flex items-center gap-2 rounded-xl bg-white px-6 py-3 font-semibold text-black transition-all hover:translate-x-[1px]"
            >
              Open Vault <ChevronRight className="h-5 w-5" />
            </button>
          </div>
        </Card>

        {/* Storage Info */}
        <Card className="mt-8 p-6">
          <h3 className="text-lg font-semibold mb-3">Storage Overview</h3>
          <div className="mb-3 flex justify-between text-sm">
            <span className="text-zinc-400">Used Space</span>
            <span className="font-medium text-white">2.4 GB / 10 GB</span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-zinc-900">
            <div
              className="h-full rounded-full bg-gradient-to-r from-blue-600 to-purple-600"
              style={{ width: "24%" }}
            />
          </div>
        </Card>

        {/* Security Note */}
        <Card className="mt-8 p-6 flex items-start gap-4">
          <div className="p-3 bg-emerald-600/20 rounded-lg">
            <Shield className="text-emerald-400 h-6 w-6" />
          </div>
          <div>
            <h3 className="text-lg font-semibold">Vault is secure</h3>
            <p className="text-sm text-zinc-400">
              All files use AES-256 encryption. Master password never stored on server.
            </p>
          </div>
        </Card>
      </main>
    </div>
  );
}
