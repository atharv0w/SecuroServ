import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useEffect } from "react";

// Layouts
import LandingLayout from "./layouts/LandingLayout.jsx";
import MainLayout from "./layouts/MainLayout.jsx";

// Public pages
import LandingPage from "./Pages/LandingPage";
import Login from "./Pages/Login.jsx";
import Signup from "./Pages/SignUp.jsx";
import ContactUs from "./Pages/ContactUs.jsx";
import Features from "./Pages/Features.jsx";

// Protected pages
import Dashboard from "./Pages/Dashboard";
import MyVaultPage from "./Pages/VaultPage.jsx";

// Components
import ProtectedRoute from "./Components/ProtectedRoute.jsx";
import { sanitizeAuthStorage } from "./auth.jsx";

export default function App() {
  // 🧹 Clean invalid tokens on app start
  sanitizeAuthStorage();

  // 🚫 Prevent browser's default file upload prompt on drag/drop
  useEffect(() => {
    const preventDefaultDrop = (e) => {
      e.preventDefault();
      e.stopPropagation();
    };

    window.addEventListener("dragover", preventDefaultDrop);
    window.addEventListener("drop", preventDefaultDrop);

    return () => {
      window.removeEventListener("dragover", preventDefaultDrop);
      window.removeEventListener("drop", preventDefaultDrop);
    };
  }, []);

  return (
    <BrowserRouter>
      <Routes>

        {/* 🌐 Public Routes (with Landing layout) */}
        <Route element={<LandingLayout />}>
          <Route path="/" element={<LandingPage />} />
          <Route path="/contact" element={<ContactUs />} />
          <Route path="/features" element={<Features />} />

          {/* 🔑 Auth Routes (login/signup) */}
          <Route
            path="/login"
            element={
              <AuthRedirect>
                <Login />
              </AuthRedirect>
            }
          />
          <Route
            path="/signup"
            element={
              <AuthRedirect>
                <Signup />
              </AuthRedirect>
            }
          />
        </Route>

        {/* 🔐 Protected Routes */}
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />

        {/* 🧩 Vault routes under MainLayout */}
        <Route
          element={
            <ProtectedRoute>
              <MainLayout />
            </ProtectedRoute>
          }
        >
          <Route path="/my-vault" element={<MyVaultPage />} />
        </Route>

        {/* 🚫 Fallback route */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

/* 🔁 AuthRedirect — Prevent logged-in users from seeing login/signup again */
function AuthRedirect({ children }) {
  const token = localStorage.getItem("sv_token");

  const isValid =
    token &&
    token !== "null" &&
    token !== "undefined" &&
    token.trim() !== "" &&
    token.split(".").length === 3; // must look like a JWT format

  if (isValid) {
    console.log("[AuthRedirect] Valid token detected → redirecting to /dashboard");
    return <Navigate to="/dashboard" replace />;
  }

  return children;
}
