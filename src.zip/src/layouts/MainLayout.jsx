import React, { useCallback, useState } from "react";
import { Outlet, useNavigate } from "react-router-dom";
import Sidebar from "../components/Sidebar.jsx";
import VaultNavbar from "../Components/VaultNavbar.jsx"; // ✅ keep naming consistent
import { clearAuth } from "../auth.jsx";

export default function MainLayout() {
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();

  const handleToggle = useCallback(() => setCollapsed((v) => !v), []);

  const handleLogout = useCallback(() => {
    console.log("[logout] clicked");
    try {
      clearAuth(); // ✅ clears sv_token, sv_role, sv_user
    } catch (err) {
      console.warn("Error clearing auth:", err);
    }
    navigate("/login", { replace: true });
  }, [navigate]);

  return (
    <div className="h-screen w-screen bg-[#0b0b0b] text-zinc-200 flex overflow-hidden">
      {/* === Sidebar === */}
      <Sidebar
        collapsed={collapsed}
        onToggle={handleToggle}
        onLogout={handleLogout}
      />

      {/* === Right Content Area === */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* === Navbar === */}
        <div className="sticky top-0 z-20 border-b border-zinc-800 bg-[#0f0f0f]">
          <VaultNavbar />
        </div>

        {/* === Page Content === */}
        <main className="flex-1 min-h-0 overflow-y-auto bg-[#0b0b0b]">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
